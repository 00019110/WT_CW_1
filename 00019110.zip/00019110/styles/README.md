This is a prototype of a website for NSP(Natural Science Project) Learning Center based in Urgench Khorezm. This Learning center has been helping students excel in their respective fields for 2+ years.


Link: ``